package com.example.atividadeproblematizadora;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface CurrencyApi {
    @GET("https://v6.exchangerate-api.com/v6/5d4bcb2e8bac467aedb63c21/latest/USD")
    Call<CurrencyResponse> getExchangeRates(@Query("5d4bcb2e8bac467aedb63c21") String accessKey);
}