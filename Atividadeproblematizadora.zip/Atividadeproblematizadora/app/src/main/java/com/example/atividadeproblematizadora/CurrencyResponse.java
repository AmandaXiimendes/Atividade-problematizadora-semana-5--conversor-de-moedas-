package com.example.atividadeproblematizadora;

import com.google.gson.annotations.SerializedName;
import java.util.Map;

public class CurrencyResponse {
    private Map<String, Object> conversion_rates;

    public Map<String, Object> getConversionRates() {
        return conversion_rates;
    }

    public void setConversionRates(Map<String, Object> conversion_rates) {
        this.conversion_rates = conversion_rates;
    }
}
