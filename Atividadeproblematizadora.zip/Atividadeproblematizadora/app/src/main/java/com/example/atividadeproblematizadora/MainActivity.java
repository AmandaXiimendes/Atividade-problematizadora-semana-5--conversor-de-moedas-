package com.example.atividadeproblematizadora;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private EditText editTextAmount;
    private Spinner spinnerFrom, spinnerTo;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextAmount = findViewById(R.id.editTextAmount);
        spinnerFrom = findViewById(R.id.spinnerFrom);
        spinnerTo = findViewById(R.id.spinnerTo);
        textViewResult = findViewById(R.id.textViewResult);
        Button buttonConvert = findViewById(R.id.buttonConvert);

        List<String> currencies = new ArrayList<>();
        currencies.add("USD");
        currencies.add("EUR");
        currencies.add("BRL");
        currencies.add("JPY");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, currencies);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFrom.setAdapter(adapter);
        spinnerTo.setAdapter(adapter);

        buttonConvert.setOnClickListener(this::onClick);
    }

    private void onClick(View view) {
        String amountStr = editTextAmount.getText().toString();
        if (amountStr.isEmpty()) {
            Toast.makeText(MainActivity.this, "Digite um valor", Toast.LENGTH_SHORT).show();
            return;
        }
        double amount = Double.parseDouble(amountStr);
        String fromCurrency = spinnerFrom.getSelectedItem().toString();
        String toCurrency = spinnerTo.getSelectedItem().toString();
        CurrencyApi currencyApi = ApiClient.getRetrofitInstance().create(CurrencyApi.class);
        Call<CurrencyResponse> call = currencyApi.getExchangeRates("5d4bcb2e8bac467aedb63c21");
        call.enqueue(new Callback<CurrencyResponse>(){

            @Override
            public void onResponse(Call<CurrencyResponse> call, Response<CurrencyResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Log.d("MainActivity", "Response: " + response.body());

                    CurrencyResponse currencyResponse = response.body();
                    Map<String, Object> conversionRates = currencyResponse.getConversionRates();
                    if (conversionRates != null) {

                        if (conversionRates.containsKey(fromCurrency) && conversionRates.containsKey(toCurrency)) {
                            Object fromRateObj = conversionRates.get(fromCurrency);
                            Object toRateObj = conversionRates.get(toCurrency);
                            if (fromRateObj != null && toRateObj != null) {
                                double fromRate = Double.parseDouble(fromRateObj.toString());
                                double toRate = Double.parseDouble(toRateObj.toString());
                                // Calcular o valor convertido
                                double convertedAmount = amount * (toRate / fromRate);
                                Log.d("MainActivity", "Taxa de " + fromCurrency + ": " + fromRate);
                                Log.d("MainActivity", "Taxa de " + toCurrency + ": " + toRate);
                                textViewResult.setText("Valor convertido: " + convertedAmount + " " + toCurrency);
                            } else {
                                Log.e("MainActivity", "Taxa de " + fromCurrency + " ou " + toCurrency + " é nula");
                                textViewResult.setText("Taxa de " + fromCurrency + " ou " + toCurrency + " é nula");
                            }
                        } else {
                            Log.e("MainActivity", "Chave '" + fromCurrency + "' ou '" + toCurrency + "' não encontrada nas taxas de conversão");
                            textViewResult.setText("Chave '" + fromCurrency + "' ou '" + toCurrency + "' não encontrada");
                        }
                    } else {
                        Log.e("MainActivity", "Conversion rates é nulo");
                        textViewResult.setText("Conversion rates é nulo");
                    }
                } else {
                    Log.e("MainActivity", "Resposta não-sucedida da API: " + response.code());
                    textViewResult.setText("Erro na resposta da API: " + response.code());
                }
            }

            @Override
            public void onFailure(@NonNull Call<CurrencyResponse> call, @NonNull Throwable t) {
                Toast.makeText(MainActivity.this, "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
}
